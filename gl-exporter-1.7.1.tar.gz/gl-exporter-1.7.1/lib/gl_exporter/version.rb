class GlExporter
  VERSION = "1.7.1".freeze
end
